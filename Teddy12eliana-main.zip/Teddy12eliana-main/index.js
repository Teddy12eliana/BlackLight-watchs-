const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/api/alerts', (req, res) => {
  res.json({ message: 'stub response' });
});

app.listen(PORT, () => {
  console.log(`Blacklight backend running on port ${PORT}`);
});
